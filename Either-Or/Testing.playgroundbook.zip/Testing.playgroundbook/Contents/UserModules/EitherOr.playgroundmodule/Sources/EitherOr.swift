public enum EitherOr<EitherType, OrType> {
    case either(EitherType)
    case or(OrType)
}
extension EitherOr: Hashable, Equatable where EitherType: Hashable, OrType: Hashable {}

